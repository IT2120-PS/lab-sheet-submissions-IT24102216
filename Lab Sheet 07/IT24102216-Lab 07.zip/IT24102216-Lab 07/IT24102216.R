setwd("C:\\Users\\samad\\Desktop\\IT24102216-Lab 07")
#01
punif(25, min = 0, max = 40) - punif(10, min = 0, max = 40)

#02
pexp(2, rate = 1/3)

#03
#i
1 - pnorm(130, 100, 15)

#ii
qnorm(0.95, 100, 15)
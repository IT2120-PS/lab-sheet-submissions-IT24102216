getwd()
setwd("C:\\Users\\IT24102216\\Desktop\\IT24102216")

#Q1 X follows the Binomial Distribution
#Q2 Probability that at least 4u student passed

# Binomial distribution: n = 50, p = 0.85
1 - pbinom(46, 50, 0.85)

#Q1 X = Number of customer calls received per hour
#Q2 X follows a Poisson distribution:
#Q3 
# Poisson distribution: lambda = 12
dpois(15, 12)
